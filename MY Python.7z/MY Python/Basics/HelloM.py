name = 'Mary'
print('PW:')
password = input()
if name == 'Mary':
     print('Hello, Mary')
     if password == 'swordfish':
         print('Access granted.')
     else:
         print('Wrong password.')