name = 'Carol'
age = 3000
if name == 'Alice':
    print('Hi, Alice.')
elif age < 12:
    print('You are not Alice, kiddo.')
elif age > 2000:
    print('Unlike you, Alice is not an undead, immortal vampire.')
elif age > 100:
    print('You are not Alice, grannie.')
spam = 0
while spam < 5:
    print('Hello, world.Spam= '+str(spam))
    spam = spam + 1
name = ''
while name != 'Ahmed':
       print('Please type your name.')
       name = input()
print('Thank you!')