name = ''
while name != 'your name':
    print('Please enter your name.')
    name = input()
print('Thank you!')
